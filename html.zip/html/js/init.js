$(document).ready(function(){
	$('.cell-no').mask('000-0000-0000');
	AOS.init();
});